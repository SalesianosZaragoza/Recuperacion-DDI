package javax.validation.constraints;

public class NotEmpty {

}
