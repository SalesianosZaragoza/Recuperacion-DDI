package com.mydemo.spring.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.mydemo.spring.model.Student;

@Service
public class StudentService {

	private List<Student> repository = new ArrayList<>();

	public Student add(Student s) {
		repository.add(s);
		return s;
	}

	public List<Student> findAll() {
		return repository;
	}

	public Student findById(long id) {
		Student result = null;
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repository.size()) {
			if (repository.get(i).getId() == id) {
				encontrado = true;
				result = repository.get(i);
			} else {
				i++;
			}
		}

		return result;
	}

	public Student edit(Student s) {
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repository.size()) {
			if (repository.get(i).getId() == s.getId()) {
				encontrado = true;
				repository.remove(i);
				repository.add(i, s);
			} else {
				i++;
			}
		}

		if (!encontrado)
			repository.add(s);

		return s;
	}

	// @PostConstruct
	// public void init() {
	// repository.addAll(Arrays.asList(new Student(1, "Antonio García", 22, 1,
	// 1200),
	// new Student(2, "María López", 21, 0, 1202), new Student(3, "Ángel Antúnez",
	// 20, 1, 1206)));
	// }

}
