package com.mydemo.spring.controller;

public @interface Valid {

}
