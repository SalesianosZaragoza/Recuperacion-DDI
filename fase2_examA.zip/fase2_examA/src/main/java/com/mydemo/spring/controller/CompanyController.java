package com.mydemo.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.mydemo.spring.model.Company;
import com.mydemo.spring.service.CompanyService;

@Controller
public class CompanyController {

	@Autowired
	public CompanyService service;

	@GetMapping({ "/", "/company/list" })
	public String list(Model model) {
		model.addAttribute("listCompanies", service.findAll());
		return "listCompany";
	}

	@GetMapping("/company/new")
	public String newCpmpanyForm(Model model) {
		model.addAttribute("companyForm", new Company());
		return "formCompany";
	}

	@PostMapping("/company/new/submit")
	public String newCompanySubmit(@Valid @ModelAttribute("companyForm") Company newCompany,
			BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			return "formCompany";
		} else {
			service.add(newCompany);
			return "redirect:/empleado/list";
		}

	}

	@GetMapping("/company/edit/{id}")
	public String editCompanyForm(@PathVariable long id, Model model) {
		Company company = service.findById(id);
		if (company != null) {
			model.addAttribute("companyForm", company);
			return "formCompany";
		} else
			return "redirect:/company/new";
	}

	@PostMapping("/company/edit/submit")
	public String editCompanySubmit(@Valid @ModelAttribute("companyForm") Company company,
			BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			return "formCompany";
		} else {
			service.edit(company);
			return "redirect://listCompany";
		}
	}

	@PostMapping("/company/edit/submit")
	public String deleteCompanySubmit(@Valid @ModelAttribute("companyForm") Company company,
			BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			return "formCompany";
		} else {
			service.delete(company);
			return "redirect://listCompany";
		}
	}

}
