package com.mydemo.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.mydemo.spring.model.Student;
import com.mydemo.spring.service.StudentService;

@Controller
public class StudentController {

	@Autowired
	public StudentService service;

	@GetMapping({ "/", "/student/list" })
	public String list(Model model) {
		model.addAttribute("listStudents", service.findAll());
		return "list";
	}

	@GetMapping("/student/new")
	public String newStudentForm(Model model) {
		model.addAttribute("studentForm", new Student());
		return "form";
	}

	@PostMapping("/student/new/submit")
	public String newStudentSubmit(@Valid @ModelAttribute("studentForm") Student newStudent,
			BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			return "form";
		} else {
			service.add(newStudent);
			return "redirect:/empleado/list";
		}

	}

	@GetMapping("/student/edit/{id}")
	public String editStudentForm(@PathVariable long id, Model model) {
		Student student = service.findById(id);
		if (student != null) {
			model.addAttribute("studentForm", student);
			return "form";
		} else
			return "redirect:/student/new";
	}

	@PostMapping("/student/edit/submit")
	public String editStudentSubmit(@Valid @ModelAttribute("studentForm") Student student,
			BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			return "form";
		} else {
			service.edit(student);
			return "redirect://list";
		}
	}

}
