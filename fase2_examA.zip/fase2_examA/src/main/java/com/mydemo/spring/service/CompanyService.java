package com.mydemo.spring.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.mydemo.spring.model.Company;

@Service
public class CompanyService {

	private List<Company> repository = new ArrayList<>();

	public Company add(Company c) {
		repository.add(c);
		return c;
	}

	public List<Company> findAll() {
		return repository;
	}

	public Company findById(long id) {
		Company result = null;
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repository.size()) {
			if (repository.get(i).getId() == id) {
				encontrado = true;
				result = repository.get(i);
			} else {
				i++;
			}
		}

		return result;
	}

	public Company edit(Company c) {
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repository.size()) {
			if (repository.get(i).getId() == c.getId()) {
				encontrado = true;
				repository.remove(i);
				repository.add(i, c);
			} else {
				i++;
			}
		}

		if (!encontrado)
			repository.add(c);

		return c;
	}

	public Company delete(Company c) {
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repository.size()) {
			if (repository.get(i).getId() == c.getId()) {
				encontrado = true;
				repository.remove(i);
				repository.add(i, c);
			} else {
				i++;
			}
		}

		if (!encontrado)
			repository.remove(c);

		return c;
	}

	// @PostConstruct
	// public void init() {
	// repository.addAll(Arrays.asList(new Student(1, "Antonio García", 22, 1,
	// 1200),
	// new Student(2, "María López", 21, 0, 1202), new Student(3, "Ángel Antúnez",
	// 20, 1, 1206)));
	// }

}
