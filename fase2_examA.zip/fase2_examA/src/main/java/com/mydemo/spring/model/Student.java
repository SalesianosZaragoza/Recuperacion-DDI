package com.mydemo.spring.model;

public class Student {

	// @Min(value = 0, message = "{empleado.id.mayorquecero}")
	private long id;
	// @NotEmpty
	private String name;
	private int age;
	private Boolean fctAssists;
	private int company;

	public Student() {
		super();
	}

	public Student(long id, String name, int age, Boolean fctAssists, int company) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.fctAssists = fctAssists;
		this.company = company;
	}

	public long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Boolean getFctAssists() {
		return fctAssists;
	}

	public void setFctAsists(Boolean fctAsists) {
		this.fctAssists = fctAsists;
	}

	public int getCompany() {
		return company;
	}

	public void setCompany(int company) {
		this.company = company;
	}

	public void setId(long id) {
		this.id = id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + age;
		result = prime * result + company;
		result = prime * result + ((fctAssists == null) ? 0 : fctAssists.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (age != other.age)
			return false;
		if (company != other.company)
			return false;
		if (fctAssists == null) {
			if (other.fctAssists != null)
				return false;
		} else if (!fctAssists.equals(other.fctAssists))
			return false;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", age=" + age + ", fctAsists=" + fctAssists + ", company="
				+ company + "]";
	}

}
