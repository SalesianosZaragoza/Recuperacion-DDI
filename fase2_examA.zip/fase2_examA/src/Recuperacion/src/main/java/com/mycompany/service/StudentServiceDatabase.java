package com.mycompany.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import com.mycompany.model.Student;
import com.mycompany.repository.StudentRepository;

@Service
@Profile("database")
public class StudentServiceDatabase implements com.mycompany.service.Service {

	private static Logger log = LogManager.getLogger(StudentServiceDatabase.class);

	@Autowired
	private StudentRepository repository;

	@Override
	public void insert(Student student) {
		repository.insert(student);
	}

	@Override
	public List<Student> listAll() {
		return repository.listAll();
	}

	public StudentRepository getRepository() {
		return repository;
	}

	public void setRepository(StudentRepository repository) {
		this.repository = repository;
	}

}
