package com.mycompany.service;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import com.mycompany.model.Student;

@Service
@Profile("file")
public class StudentService implements com.mycompany.service.Service {

	private static Logger log = LogManager.getLogger(StudentService.class);

	private List<Student> students = new ArrayList<>();

	@Override
	public void insert(Student student) {

		log.info("inserting new student:" + student);

		List<String> lines = Arrays.asList(students.toString());
		Path file = Paths.get(System.getProperty("user.dir") + "/the-file-name.txt");
		try {
			Files.write(file, lines, Charset.forName("UTF-8"), StandardOpenOption.APPEND);
		} catch (IOException e) {
			throw new RuntimeException("error al escribir en el fichero", e);
		}
		students.add((Student) students);
	}

	@Override
	public List<Student> listAll() {
		List<Student> listStudent = new ArrayList<>();
		Path file = Paths.get(System.getProperty("user.dir") + "/the-file-name.txt");
		List<String> readAllLines = new ArrayList<>();
		try {
			readAllLines = Files.readAllLines(file, Charset.forName("UTF-8"));
		} catch (IOException e) {
			log.error("error al leer del fichero", e);
		}

		for (String line : readAllLines) {
			Student student = new Student();
			student.setName(line);
			log.info("showing student:" + student);
			listStudent.add(student);
		}
		return listStudent;
	}

}
