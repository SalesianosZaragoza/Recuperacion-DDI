package com.mycompany.controller;

import java.util.Collection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mycompany.model.FctAssists;
import com.mycompany.model.Student;

@Controller
public class IndexController {

	private static Logger log = LogManager.getLogger(IndexController.class);
	@Autowired
	private Student student;

	@GetMapping("/")
	public ModelAndView index() {
		ModelAndView modelAndView = new ModelAndView("index");
		modelAndView.addObject("student", this.student);
		return modelAndView;
	}

	@PostMapping("studentInsert")
	public ModelAndView studentInsert(Student student) {
		log.debug("studentInsert:" + this.student.toString());
		addPageData(student);

		ModelAndView modelAndView = new ModelAndView("index");
		modelAndView.addObject("student", this.student);
		return modelAndView;
	}

	@PostMapping("fctAssistsInsert")
	public ModelAndView fctAssistsInsert(Student student) {
		log.debug("fctAssistsInsert:" + this.student.toString());
		addPageData(student);

		ModelAndView modelAndView = new ModelAndView("index");
		modelAndView.addObject("student", this.student);
		return modelAndView;
	}

	@PostMapping("fctAssistsInsert")
	public ModelAndView companyInsert(Student student) {
		log.debug("companyInsert:" + this.student.toString());
		addPageData(student);

		ModelAndView modelAndView = new ModelAndView("index");
		modelAndView.addObject("student", this.student);
		return modelAndView;
	}

	private void addPageData(Student studentForm) {
		if (StringUtils.hasLength(studentForm.getName())) {
			this.student.setName(studentForm.getName());
		}

		if (StringUtils.hasLength(studentForm.getName())) {
			Collection<? extends FctAssists> student = (Collection<? extends FctAssists>) new Student();
			((FctAssists) student).setName(studentForm.getName());
			studentForm.setName("");
			this.student.getData().addAll(student);
		}

		if (StringUtils.hasLength(studentForm.getFctAssistsName())) {
			FctAssists student = new FctAssists();
			student.setName(studentForm.getFctAssistsName());
			studentForm.setFctAssistsName("");
			this.student.getFctAssists().add(student);
		}
	}

}
