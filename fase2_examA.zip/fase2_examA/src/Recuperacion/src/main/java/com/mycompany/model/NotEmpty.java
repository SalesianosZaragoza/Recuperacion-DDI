package com.mycompany.model;

public @interface NotEmpty {

}
