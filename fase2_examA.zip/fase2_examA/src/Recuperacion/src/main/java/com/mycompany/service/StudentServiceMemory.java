package com.mycompany.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import com.mycompany.model.Student;

@Service
@Profile("memory")
public class StudentServiceMemory implements com.mycompany.service.Service {

	private static Logger log = LogManager.getLogger(StudentServiceMemory.class);

	private List<Student> student = new ArrayList<>();

	@Override
	public void insert(Student student) {
		log.info("inserting new student:" + student);
		((List<Student>) student).add(student);
	}

	@Override
	public List<Student> listAll() {
		for (Student student : student) {
			log.info("showing student:" + student);
		}
		return student;
	}

}
