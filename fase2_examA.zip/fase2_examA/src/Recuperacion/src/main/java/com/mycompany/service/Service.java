package com.mycompany.service;

import java.util.List;

import com.mycompany.model.Student;

public interface Service {

	public void insert(Student fctAssists);

	public List<Student> listAll();

}
