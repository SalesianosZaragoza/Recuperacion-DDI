package com.mycompany.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mycompany.model.Student;
import com.mycompany.service.Service;

@Controller
public class StudentController {

	private static Logger log = LogManager.getLogger(StudentController.class);

	@Autowired
	private Service service;

	@GetMapping("/Company")
	public ModelAndView index() {
		log.debug("Insert a new student");
		ModelAndView modelAndView = new ModelAndView("student");
		modelAndView.addObject("student", service.listAll());
		modelAndView.addObject("student", new Student());
		return modelAndView;
	}

	@PostMapping("/studentInsert")
	public ModelAndView create(@ModelAttribute("student") Student student) {
		log.debug("inserting student");
		service.insert(student);
		ModelAndView modelAndView = new ModelAndView("student");
		modelAndView.addObject("student", new Student());
		modelAndView.addObject("fctAssists", service.listAll());
		return modelAndView;
	}

}
