create table IF NOT EXISTS oldWarehouse(
	id bigint auto_increment,
    	name varchar(25)
);

create table IF NOT EXISTS newWarehouse(
	id bigint auto_increment,
    	name varchar(25)
);

create table IF NOT EXISTS BOOK(
	id bigint auto_increment,
isbn varchar(25),
dateEdition date,
oldWarehouse INT,
newWarehouse INT,
FOREIGN KEY (oldWarehouse  ) REFERENCES oldWarehouse(id),
FOREIGN KEY (newWarehouse  ) REFERENCES newWarehouse(id)
);
