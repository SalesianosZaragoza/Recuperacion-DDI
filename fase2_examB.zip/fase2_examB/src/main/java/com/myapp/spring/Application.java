package com.myapp.spring;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.myapp.spring.repository.BookRepository;
import com.myapp.spring.repository.WarehouseRepository;
import com.myapp.spring.upload.storage.StorageService;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Bean
	CommandLineRunner init(StorageService storageService) {
		return (args) -> {
			storageService.deleteAll();
			storageService.init();
		};
	}

	@Bean
	CommandLineRunner initData(BookRepository repositorio) {
		return (args) -> {

//			

			// List<long> books = Arrays.asList(1002, 1003, 1004, 1255, 1022, 1580, 2000,
			// 2001, 2020, 2010, 2011, 2055, 2100, 2120, "2155, 2200, 2231, 2241,
			// 2311, 2315, 2355, 2358, 2566, 2567, 2577, 2789, 2591, 2600, 5222,
			// 2701, 2750, 2760, 2780, 2890, 2899, 2910, 3000, 3002, 3500, 4255,
			// 4980);

			List<String> ISBN = Arrays.asList("25265458985", "25582594696", "695586325", "2598269855", "59154458",
					"826548562", "255269444", "2659532057", "288523989", "268588569", "026494294", "152819854",
					"268955933", "256325993", "256636588", "28233+68", "55881268477", "1556955881", "5494797984139",
					"975188949", "547913688", "582225888", "258888852", "178752258", "25824528588");

			Collections.shuffle(ISBN);

			// BookRepository.saveAll(IntStream.rangeClosed(1, ISBN.size()).mapToLong((i) ->
			// {
			// long id = id.get(i - 1);
			// String ISBN = ISBN.get(ThreadLocalRandom.current().nextInt(ISBN.size()));
			// String dateEdition =
			// dateEdition.get(ThreadLocalRandom.current().nextInt(dateEdition.size()));
			// return new Book(String.format("%s %s %s", id, ISBN, dateEdition);

			// }).collect(Collectors.toList()));

		};
	}

	@Bean
	CommandLineRunner initData(WarehouseRepository repositorio) {
		return (args) -> {
		};
	}

}
