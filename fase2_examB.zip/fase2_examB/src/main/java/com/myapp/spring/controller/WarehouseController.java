package com.myapp.spring.controller;

import javax.validation.constraints.Valid;

//import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import com.myapp.spring.model.Warehouse;
import com.myapp.spring.service.WarehouseService;
import com.myapp.spring.upload.storage.StorageService;

@Controller
public class WarehouseController {

	@Autowired
	private WarehouseService service;

	@Autowired
	private StorageService storageService;

	@GetMapping({ "/", "/warehouse/list" })
	public String list(Model model) {
		model.addAttribute("listWarehouses", service.findAll());
		return "listWarehouse";
	}

	@GetMapping("/warehouse/new")
	public String newWarehouseForm(Model model) {
		model.addAttribute("warehouseForm", new Warehouse());
		return "formWarehouse";
	}

	@PostMapping("/warehouse/new/submit")
	public String newWarehouseSubmit(@Valid @ModelAttribute("warehouseForm") Warehouse newWarehouse,
			BindingResult bindingResult, @RequestParam("file") MultipartFile file) {

		if (bindingResult.hasErrors()) {
			return "formWarehouse";
		} else {
			if (!file.isEmpty()) {
				String ISBN = storageService.store(file, newWarehouse.getId());
				newWarehouse.setString(MvcUriComponentsBuilder
						.fromMethodName(WarehouseController.class, "serveFile", ISBN).build().toUriString());
			}
			service.add(newWarehouse);
			return "redirect:/warehouse/list";
		}
	}

	@GetMapping("/warehouse/edit/{id}")
	public String editWarehouseForm(@PathVariable long id, Model model) {
		Warehouse warehouse = service.findById(id);
		if (warehouse != null) {
			model.addAttribute("warehouseForm", warehouse);
			return "formWarehouse";
		} else
			return "redirect:/warehouse/new";
	}

	@PostMapping("/warehouse/edit/submit")
	public String editWarehouseSubmit(@Valid @ModelAttribute("warehouseForm") Warehouse newWarehouse,
			BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			return "form";
		} else {
			service.edit(newWarehouse);
			return "redirect:/warehouse/list";
		}
	}

	@GetMapping("/files/{filename:.+}")
	@ResponseBody
	public ResponseEntity<Resource> serveFile(@PathVariable String filename) {
		Resource file = storageService.loadAsResource(filename);
		return ResponseEntity.ok().body(file);
	}

}
