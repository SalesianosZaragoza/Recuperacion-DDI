package com.myapp.spring.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Book {

	@Id
	@GeneratedValue
	// @Min(value=0, message="{empleado.id.mayorquecero}")
	private long id;

	@Column(nullable = false)
	// @NotEmpty
	private String ISBN;

	private Date dateEdition;

	private int oldWarehouse;

	private int newWarehouse;

	public Book(long id, String iSBN, int oldWarehouse, int newWarehouse) {
		super();
		this.id = id;
		ISBN = iSBN;
		this.dateEdition = dateEdition;
		this.oldWarehouse = oldWarehouse;
		this.newWarehouse = newWarehouse;
	}

	public Book(int i, String string, int j, Object object, int k) {
	}

	public Book() {
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getISBN() {
		return ISBN;
	}

	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}

	public Date getDateEdition() {
		return dateEdition;
	}

	public void setDateEdition(Date dateEdition) {
		this.dateEdition = dateEdition;
	}

	public int getOldWarehouse() {
		return oldWarehouse;
	}

	public void setOldWarehouse(int oldWarehouse) {
		this.oldWarehouse = oldWarehouse;
	}

	public int getNewWarehouse() {
		return newWarehouse;
	}

	public void setNewWarehouse(int newWarehouse) {
		this.newWarehouse = newWarehouse;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ISBN == null) ? 0 : ISBN.hashCode());
		result = prime * result + ((dateEdition == null) ? 0 : dateEdition.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result + newWarehouse;
		result = prime * result + oldWarehouse;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		if (ISBN == null) {
			if (other.ISBN != null)
				return false;
		} else if (!ISBN.equals(other.ISBN))
			return false;
		if (dateEdition == null) {
			if (other.dateEdition != null)
				return false;
		} else if (!dateEdition.equals(other.dateEdition))
			return false;
		if (id != other.id)
			return false;
		if (newWarehouse != other.newWarehouse)
			return false;
		if (oldWarehouse != other.oldWarehouse)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Book [id=" + id + ", ISBN=" + ISBN + ", dateEdition=" + dateEdition + ", oldWarehouse=" + oldWarehouse
				+ ", newWarehouse=" + newWarehouse + "]";
	}

	public Book orElse(Object object) {

		return null;
	}

	public void setString(String uriString) {

	}

}
