package com.myapp.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.myapp.spring.model.Book;
import com.myapp.spring.repository.BookRepository;

@Primary
@Service("bookServiceDB")
public class BookServiceDB implements BookService {

	@Autowired
	private BookRepository repository;

	@Override
	public Book add(Book b) {
		return repository.save(b);
	}

	@Override
	public List<Book> findAll() {
		return repository.findAll();
	}

	@Override
	public Book findById(long id) {
		return repository.findById(id).orElse(null);
	}

	@Override
	public Book edit(Book b) {
		return repository.save(b);
	}

	public void delete(Book b) {
		repository.delete(b);
	}

	public List<Book> buscador(String cadena) {
		return repository.lookForISBN(cadena.toLowerCase());
	}

	public void remove(Book newBook) {
	}

}
