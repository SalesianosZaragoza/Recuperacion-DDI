package com.myapp.spring.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

import com.myapp.spring.model.Book;

@Service("bookServiceMemory")
public class BookServiceMemory implements BookService {

	private List<Book> repository = new ArrayList<>();

	public Book add(Book b) {
		repository.add(b);
		return b;
	}

	public List<Book> findAll() {
		return repository;
	}

	public Book findById(long id) {
		Book result = null;
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repository.size()) {
			if (repository.get(i).getId() == id) {
				encontrado = true;
				result = repository.get(i);
			} else {
				i++;
			}
		}

		return result;
	}

	public Book edit(Book b) {
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repository.size()) {
			if (repository.get(i).getId() == b.getId()) {
				encontrado = true;
				repository.get(i);
				repository.add(i, b);

			} else {
				i++;
			}
		}

		if (!encontrado)
			repository.add(b);

		return b;
	}

	public void delete(Book b) {
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repository.size()) {
			if (repository.get(i).getId() == b.getId()) {
				encontrado = true;
				repository.remove(i);
				repository.add(i, b);
			} else {
				i++;
			}
		}

		if (!encontrado)
			repository.remove(b);

		return;
	}

	@PostConstruct
	public void init() {
		// repository.addAll(Arrays.asList(new Book(1001, "2536615896", 01/01/2000, 10);

	}

}
