package com.myapp.spring.service;

import java.util.List;

import com.myapp.spring.model.Book;

public interface BookService {

	public Book add(Book b);

	public List<Book> findAll();

	public Book edit(Book b);

	public void delete(Book b);

	Book findById(long id);

}
