package com.myapp.spring.service;

import java.util.List;

import com.myapp.spring.model.Warehouse;

public interface WarehouseService {

	public Warehouse add(Warehouse w);

	public List<Warehouse> findAll();

	public Warehouse findById(long id);

	public Warehouse edit(Warehouse w);

	public void delete(Warehouse w);

	Warehouse findByISBN(String ISBN);

}
