package com.myapp.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import com.myapp.spring.model.Book;
import com.myapp.spring.service.BookService;
import com.myapp.spring.upload.storage.StorageService;

@Controller
public class BookController {

	@Autowired
	private BookService service;

	@Autowired
	private StorageService storageService;

	@GetMapping({ "/", "/book/list" })
	public String list(Model model) {
		model.addAttribute("listBooks", service.findAll());
		return "list";
	}

	@GetMapping("/book/new")
	public String newBookForm(Model model) {
		model.addAttribute("bookForm", new Book());
		return "form";
	}

	@PostMapping("/book/new/submit")
	public String newWarehouseSubmit(@ModelAttribute("bookForm") Book newBook, BindingResult bindingResult,
			@RequestParam("file") MultipartFile file) {

		if (bindingResult.hasErrors()) {
			return "form";
		} else {
			if (!file.isEmpty()) {
				String ISBN = storageService.store(file, newBook.getId());
				newBook.setString(MvcUriComponentsBuilder.fromMethodName(BookController.class, "serveFile", ISBN)
						.build().toUriString());
			}
			service.add(newBook);
			return "redirect:/book/list";
		}
	}

	@GetMapping("/book/edit/{id}")
	public String editBookForm(@PathVariable long id, Model model) {
		Book book = service.findById(id);
		if (book != null) {
			model.addAttribute("warehouseForm", book);
			return "form";
		} else
			return "redirect:/book/new";
	}

	@PostMapping("/book/edit/submit")
	public String editBookSubmit(@ModelAttribute("warehouseForm") Book newBook, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			return "form";
		} else {
			service.edit(newBook);
			return "redirect:/book/list";
		}
	}

	@GetMapping("/files/{filename:.+}")
	@ResponseBody
	public ResponseEntity<Resource> serveFile(@PathVariable String filename) {
		Resource file = storageService.loadAsResource(filename);
		return ResponseEntity.ok().body(file);
	}

}
