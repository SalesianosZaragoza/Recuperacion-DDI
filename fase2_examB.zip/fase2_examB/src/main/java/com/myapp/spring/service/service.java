package com.myapp.spring.service;

import java.util.List;

import com.myapp.spring.model.Book;

public interface service {

	static List<Book> findAll() {
		return null;
	}

	static void add(Book newBook) {

	}

	static Book findById(long id) {
		return null;
	}

	static void edit(Book newBook) {
	}

	static void remove(Book newBook) {
	}

}
