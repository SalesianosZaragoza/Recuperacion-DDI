package com.myapp.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.myapp.spring.model.Warehouse;
import com.myapp.spring.repository.WarehouseRepository;

@Primary
@Service("warehouseServiceDB")
public class WarehouseServiceDB implements WarehouseService {

	@Autowired
	private WarehouseRepository repositorio;

	@Override
	public Warehouse add(Warehouse w) {
		return repositorio.save(w);
	}

	@Override
	public List<Warehouse> findAll() {
		return repositorio.findAll();
	}

	// @Override
	// public Warehouse findById(long id) {
	// return repositorio.findById(id).orElse(null);
	// }

	// @Override
	// public Warehouse findByISBN(String ISBN) {
	// return repositorio.findByISBN(ISBN).orElse(null);
	// }

	@Override
	public Warehouse edit(Warehouse w) {
		return repositorio.save(w);
	}

	public void delete(Warehouse w) {
		return;
	}

	public void remove(Warehouse newWarehouse) {

	}

	@Override
	public Warehouse findById(long id) {
		return null;
	}

	@Override
	public Warehouse findByISBN(String ISBN) {
		return null;
	}

}
