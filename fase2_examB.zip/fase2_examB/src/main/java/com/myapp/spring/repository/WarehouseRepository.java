package com.myapp.spring.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.myapp.spring.model.Warehouse;

public interface WarehouseRepository extends JpaRepository<Warehouse, Long> {

	List<Warehouse> findById(long id);

	// List<Warehouse> findByISBN(String ISBN);

	@Query("select b from Warehouse w where lower(w.id) like %?1% or lower(w.name)")
	List<Warehouse> lookForId(long id);

}
