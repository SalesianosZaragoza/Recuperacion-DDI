package com.myapp.spring.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

import com.myapp.spring.model.Warehouse;

@Service("WarehouseServiceMemory")
public abstract class WarehouseServiceMemory implements WarehouseService {

	private List<Warehouse> repository = new ArrayList<>();

	public Warehouse add(Warehouse w) {
		repository.add(w);
		return w;
	}

	public List<Warehouse> findAll() {
		return repository;
	}

	public Warehouse findById(long id) {
		Warehouse result = null;
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repository.size()) {
			if (repository.get(i).getId() == id) {
				encontrado = true;
				result = repository.get(i);
			} else {
				i++;
			}
		}

		return result;
	}

	public Warehouse edit(Warehouse w) {
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repository.size()) {
			if (repository.get(i).getId() == w.getId()) {
				encontrado = true;
				repository.remove(i);
				repository.add(i, w);
			} else {
				i++;
			}
		}

		if (!encontrado)
			repository.add(w);

		return w;
	}

	public void delete(Warehouse w) {
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < repository.size()) {
			if (repository.get(i).getId() == w.getId()) {
				encontrado = true;
				repository.remove(i);
				repository.add(i, w);
			} else {
				i++;
			}
		}

		if (!encontrado)
			repository.remove(w);

		return;
	}

	@PostConstruct
	public void init() {
		repository.addAll(Arrays.asList(new Warehouse(1002, "SuperWarehouse"), new Warehouse(2005, "BestWarehouse"),
				new Warehouse(3, "LookBooks")));
	}

}
