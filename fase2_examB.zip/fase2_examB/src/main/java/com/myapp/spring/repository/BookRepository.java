package com.myapp.spring.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.myapp.spring.model.Book;
import com.myapp.spring.model.Warehouse;

public interface BookRepository extends JpaRepository<Book, Long> {

	Book findById(long id);

	@Query("select b from Book b where lower(b.ISBN) like %?1% or lower(b.id)")
	List<Book> lookForISBN(String ISBN);

	static List<Warehouse> lookForName(String lowerCase) {

		return null;
	}

	// @Query(value="SELECT * FROM BOOK WHERE LOWER(ISBN)", nativeQuery=true)

}
