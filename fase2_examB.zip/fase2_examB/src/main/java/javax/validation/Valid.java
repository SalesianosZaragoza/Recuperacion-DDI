package javax.validation;

public class Valid {

}
