package javax.validation.constraints;

public @interface Valid {

}
