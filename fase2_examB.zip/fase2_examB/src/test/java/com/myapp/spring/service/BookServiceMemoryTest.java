package com.myapp.spring.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BookServiceMemoryTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
